<?php 

    require 'DAOS/db.php';
    require 'DAOS/clienteDAO.php';
    require 'DAOS/habitacionDAO.php';
    require 'DAOS/reservaDAO.php';
    require 'DAOS/checkDAO.php';
    require 'DAOS/historialDAO.php';


?>