<?php 

    require 'DAOS/db.php';
    require 'DAOS/usuarioDAO.php';
    require 'DAOS/rolDAO.php';

?>