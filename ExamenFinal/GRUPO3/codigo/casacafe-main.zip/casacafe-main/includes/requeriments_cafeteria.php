<?php 
    require 'DAOS/db.php';
    require 'DAOS/usuarioDAO.php';
    require 'DAOS/historialDAO.php';
    require 'DAOS/productoDAO.php';
    require 'DAOS/inventarioDAO.php';
    require 'DAOS/ventaDAO.php';

?>