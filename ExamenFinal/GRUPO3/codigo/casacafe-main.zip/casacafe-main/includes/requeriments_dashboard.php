<?php 

    require 'DAOS/db.php';
    require 'DAOS/reservaDAO.php';
    require 'DAOS/ventaDAO.php';



?>