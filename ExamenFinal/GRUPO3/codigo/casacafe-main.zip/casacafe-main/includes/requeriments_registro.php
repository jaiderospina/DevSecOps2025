<?php 
    require 'DAOS/db.php';
    require 'DAOS/usuarioDAO.php';
    require 'DAOS/rolDAO.php';

    require 'DAOS/administradorDAO.php';
    require 'DAOS/coordinadorDAO.php';
    require 'DAOS/empleadoDAO.php';

?>